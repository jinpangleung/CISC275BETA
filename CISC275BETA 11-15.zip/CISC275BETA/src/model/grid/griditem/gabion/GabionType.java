package model.grid.griditem.gabion;

public enum GabionType {
	CONCRETE, OYSTER
}
