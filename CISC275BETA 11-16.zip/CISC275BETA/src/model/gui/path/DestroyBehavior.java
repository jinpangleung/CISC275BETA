package model.gui.path;

/**
 * DestroyBehavior
 * GridItem should be destroyed when the path is finished
 * 
 * @author Eric
 *
 */

public class DestroyBehavior implements PathBehavior {
	
	public void terminate(Path p){
		
	}

}
