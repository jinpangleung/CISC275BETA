package model.drawing;

/**
 * Offset
 * Determines how to offset an image
 * CENTER centers the image
 * @author Eric
 *
 */

public enum Offset {
	
	CENTER

}
