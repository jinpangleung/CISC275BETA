package model.drawing;

import java.awt.Graphics;

/**
 * DrawableObject
 * Any object that can be drawn
 * Drawable object contains a Coord
 * 
 * @see Coord
 * @author Eric
 *
 */

public class DrawableObject {
	
	private Coord coord;
	private Animation animation;
	
	public DrawableObject(){
		this.coord = new Coord(0.0, 0.0);
	}
	
	public void draw(Graphics g){
		animation.draw(g, (int) coord.getX(), (int) coord.getY());
	}
	
	public void drawStatic(Graphics g){
		animation.drawStatic(g, (int) coord.getX(), (int) coord.getY());
	}
	
	public Coord getCoord(){
		return coord;
	}
	
	public void setCoord(Coord c){
		this.coord = c;
	}
	
	public void setCoord(int x, int y){
		this.coord.setX(x);
		this.coord.setY(y);
	}

}
