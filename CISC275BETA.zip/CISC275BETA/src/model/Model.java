package model;

import java.awt.Graphics;
import model.gui.component.*;

/**
 * Model
 * Model holds all of the game elements
 * It should be updatable based on elapsed time since last update
 * @author Eric
 *
 */

public class Model {
	
	// Model Attributes
	private Component defaultComponent;
	private ComponentMapping componentMapping;
	
	public void initialize(int screenWidth, int screenHeight){
		System.out.println("\tModel is being intialized");
		defaultComponent = new Component(0, 0, screenWidth, screenHeight);
		componentMapping = new ComponentMapping(defaultComponent, screenWidth, screenHeight);
	}
	
	public void update(long timeElapsed){
		
	}
	
	public void draw(Graphics g){
		
	}
	
	public void mouseClicked(int mouseX, int mouseY){
		System.out.println("\tMouseClicked");
		componentMapping.mouseClicked(mouseX, mouseY);
	}
	
	public void mouseReleased(int mouseX, int mouseY){
		System.out.println("\tMouseReleased");
		componentMapping.mouseReleased(mouseX, mouseY);
	}
	
	public void mouseDragged(int mouseX, int mouseY){
		System.out.println("\tMouse Dragged");
	}

}
