package model.gui.component;

/**
 * Component
 * Component is a static "frame" that exists within a component mapping
 * It has dimensions and can handle mouse clicks and mouse releases within it
 * 
 * @see ComponentMapping
 * @author Eric
 *
 */

public class Component {
	
	private ComponentPosition topLeft;
	private ComponentPosition bottomRight;
	
	public Component(ComponentPosition topLeft, int width, int height){
		this.topLeft = topLeft;
		this.bottomRight = new ComponentPosition(topLeft.getX() + width - 1, topLeft.getY() + height - 1);
	}
	
	public Component(int x, int y, int width, int height){
		this.topLeft = new ComponentPosition(x, y);
		this.bottomRight = new ComponentPosition(x + width - 1, y + height - 1);
	}
	
	public boolean isWithin(int x, int y){
		return topLeft.getX() <= x && bottomRight.getX() >= x &&
				topLeft.getY() <= y && bottomRight.getY() >= y;
	}
	
	public void mouseClicked(int mouseX, int mouseY){
		// Do nothing
	}
	
	public void mouseReleased(int mouseX, int mouseY){
		// Do nothing
	}

	public ComponentPosition getTopLeft() {
		return topLeft;
	}

	public void setTopLeft(ComponentPosition topLeft) {
		this.topLeft = topLeft;
	}

	public ComponentPosition getBottomRight() {
		return bottomRight;
	}

	public void setBottomRight(ComponentPosition bottomRight) {
		this.bottomRight = bottomRight;
	}

}
