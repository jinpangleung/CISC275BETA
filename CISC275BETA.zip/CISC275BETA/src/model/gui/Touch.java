package model.gui;

import java.awt.Graphics;
import model.drawing.DrawableObject;

/**
 * Touch
 * Touch keeps a pointer to a DrawableObject
 * Touch is exclusively used for dragging DrawableObjects around the screen
 * Touch needs to be explicitly told when to pick something up and when to drop something using clamp and unClamp
 * The Touch pointer should never be null, because Touch should be able to draw the object it's holding
 * 
 * @author Eric
 *
 */

public class Touch {
	
	private DrawableObject holding;
	private DrawableObject nullObject;
	
	public Touch(){
		nullObject = new DrawableObject();
		holding = nullObject;
	}
	
	public void mouseDragged(int mouseX, int mouseY){
		this.holding.setCoord(mouseX, mouseY);
	}
	
	public void clamp(DrawableObject objectToBeClamped){
		this.holding = objectToBeClamped;
	}
	
	public void unClamp(){
		holding = nullObject;
	}
	
	public void draw(Graphics g){
		holding.draw(g);
	}

}
